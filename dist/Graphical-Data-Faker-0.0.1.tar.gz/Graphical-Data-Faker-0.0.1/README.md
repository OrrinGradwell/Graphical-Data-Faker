# Graphical-Data-Faker

a Tool that can spoof personal details for use during development or testing.  

For now, this will only spoof:  
* First Name
* Last Name
* RSA ID Number
* ZA Cell Numbers
* Email Address  

Long term goal is to extend this to Business details as well as a few usability enhancements.